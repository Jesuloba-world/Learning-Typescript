function add(n1: number, n2: number): number {
	// function return type
	return n1 + n2;
}

function printResult(num: number): void {
	// function return type (void)
	console.log("Result is " + num);
}

function addAndHandle(n1: number, n2: number, cb: (num: number) => void): void {
	// function callback types
	const result = add(n1, n2);
	cb(result);
}

printResult(add(5, 10));

let combinedValues: (a: number, b: number) => number; // function type

combinedValues = add;

console.log(combinedValues(5, 5));

addAndHandle(5, 20, (result) => {
	console.log(result);
});
