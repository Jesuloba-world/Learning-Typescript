let userInput: unknown; // The unknown type
let userName: string;

userInput = 5;
userInput = "John";

if (typeof userInput === "string") {
	userName = userInput;
}

function generateError(message: string, code: number): never {
	// The never Type
	throw { message: message, errorCode: code };
}

generateError("An error occurred!!", 500);
