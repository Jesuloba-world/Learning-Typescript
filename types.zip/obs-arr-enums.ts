// const person: {
// 	name: string;
// 	age: number;
// 	hobbies: string[];
// 	role: [number, string];
// } = {
// 	name: "John",
// 	age: 20,
// 	hobbies: ["Swimming", "Gaming", "Jumping"],
// 	role: [2, "author"], //tuple
// };

enum Roles {
	ADMIN,
	READ_ONLY,
	AUTHOR,
}

const person = {
	name: "John",
	age: 20,
	hobbies: ["Swimming", "Gaming", "Jumping"],
	role: Roles.ADMIN,
};

let favourites: string[];
favourites = ["Sports"];

console.log(person.name);

for (const hobby of person.hobbies) {
	console.log(hobby);
}

if (person.role === Roles.ADMIN) {
	console.log("is the admin");
}
